Hi!!! :D

This is my X file type! Go ahead and edit it with the openeditor.bat
located in the editor folder, or convert txt files to x files using the convert.bat located in the convert folder!
Or, if you're really fancy, go ahead and open Command Prompt and enter cd (path to the batch file) and then enter 
"convert.bat (path to the target txt)". If you don't want to use Command Prompt, just drag the txt onto the batch
file!

:3